import React from "react";

const Notes = (props) => {
    return (
        <section className="section">
            <p><strong>Note: </strong> This tool generates new password using javascript. It does not store or send it across internet. Because we believe the best place to store your passwords is right in your head :)</p>
            <p><strong>Disclaimer: </strong> This tool/website and its authors are not responsible for any loss of data or personal information. Passwords are used at the user's own risk and no liability will be asumed. By using this tool/website, you agree that the tool/website and its authors are not liable for any losses incurred. This tool/website and its authors are not responsible or liable, directly or indirectly, for any damage or loss caused by or in connection with the use of, or reliance on, any such content, goods or services available on or through this tool/website.</p>
        </section>
    );
}

export default Notes;